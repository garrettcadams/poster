<?php if (!defined('APP_VERSION')) die("Yo, what's up?"); ?>
<?php 
    return [
        "idname" => "auto-comment",
        "plugin_name" => "Auto Comment",
        "plugin_uri" => "http://getnextpost.io",
        "author" => "Nextpost",
        "author_uri" => "http://getnextpost.io",
        "version" => "1.0.0",
        "desc" => "Auto Comment is a very useful module to interact with new users.",
        "icon_style" => "background-color: #A077FF; background: linear-gradient(-135deg, #A077FF 0%, #02CDFF 100%); color: #fff; font-size: 18px;"
    ];
    